"# iVision-Data-Collector-API-1" 

This API Enables you to collect images when a motion is triggered.
The input feed is given from IP Cam or Device Cam.

The gathered images could be used for training your ML Model.